#include <iostream>
#include <string>
#include <iomanip>
#include <stdlib.h>	

using namespace std;

//print a menu for the user
void menu() {
	cout << "**************************" << endl;
	cout << "* 1 - Add One Hour       *" << endl;
	cout << "* 2 - Add One Minute     *" << endl;
	cout << "* 3 - Add One Second     *" << endl;
	cout << "* 4 - Exit Program       *" << endl;
	cout << "**************************" << endl;

}

int main() {
	//initiate variables
	char userChoice = 'Y';
	int userInput;
	int hour1 = 12;
	int minute1 = 00;
	int second1 = 00;
	int hour2 = 00;
	int minute2 = 00;
	int second2 = 00;
	string timeOfDay = "AM";
	bool exit = false;

	//allow loop to begin showing clock and taking input
	while (userChoice == 'Y') {
		cout << "**************************    **************************" << endl;
		cout << "*      12-Hour Clock     *    *      24-Hour clock     *" << endl;
		cout << "*      " << setw(2) << setfill('0') << hour1 << ":";
		cout << setw(2) << setfill('0') << minute1 << ":";
		cout << setw(2) << setfill('0') << second1 << " " << timeOfDay << "       *    *        ";
		cout << setw(2) << setfill('0') << hour2 << ":";
		cout << setw(2) << setfill('0') << minute2 << ":";
		cout << setw(2) << setfill('0') << second2 << "        *" << endl;
		cout << "**************************    **************************" << endl;

		//print menu
		menu();

		//take user input
		cin >> userInput;

		//loop taking user input for menu option
		while (userInput != exit) {
			if (userInput == 1) { //adds 1 hour
				if (hour1 == 12) {
					hour1 = 01;
				}
				else {
					hour1 += 1;
				}

				if (hour2 == 23) {
					hour2 += 01;
				}
				else {
					hour2 += 1;
				}
			
			}
			else if (userInput == 2) { //add one minute
				if ((minute1 == 59) && (minute2 == 59)) {
					minute1 = 00;
					minute2 = 00;
					if (hour1 == 12) {
						hour1 = 01;
					}
					if (hour2 == 23) {
						hour2 = 00;
					}
					else if ((hour1 <= 11) && (hour2 <= 22)) {
						hour1 += 1;
						hour2 += 1;
					}
				}
				else if ((minute1 < 60) && (minute2 < 60)) {
					minute2 += 1;
					minute1 += 1;
				}
			}
			else if (userInput == 3) { //add one second
				if ((second1 == 59) && (second2 == 59)) {
					second1 = 00;
					second2 = 00;
					minute1 += 1;
					minute2 += 1;
				}
				else if ((second1 < 60) && (second2 < 60)) {
					second1 += 1;
					second2 += 1;
				}
			}
			else if (userInput == 4) { //closes program
				cout << "Program closing..." << endl;
				exit = true;
				return 0;
			}
			else { //outputs error if user inputs invalid input
				cout << "Invalid input!" << endl;
			}

			//print clock again
			cout << "**************************    **************************" << endl;
			cout << "*      12-Hour Clock     *    *      24-Hour clock     *" << endl;
			cout << "*      " << setw(2) << setfill('0') << hour1 << ":";
			cout << setw(2) << setfill('0') << minute1 << ":";
			cout << setw(2) << setfill('0') << second1 << " " << timeOfDay << "       *    *        ";
			cout << setw(2) << setfill('0') << hour2 << ":";
			cout << setw(2) << setfill('0') << minute2 << ":";
			cout << setw(2) << setfill('0') << second2 << "        *" << endl;
			cout << "**************************    **************************" << endl;

			//print menu
			menu(); 

			//take user input again
			cin >> userInput;
		}
	}
}